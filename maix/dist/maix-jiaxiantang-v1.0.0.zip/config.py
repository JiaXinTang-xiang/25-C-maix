"""
配置文件 —— 所有可调参数集中管理
根据实际场景修改这些值，无需改动业务代码
"""

# ============================================================
# 摄像头设置
# ============================================================
CAMERA_WIDTH = 320
CAMERA_HEIGHT = 240
CAMERA_SKIP_FRAMES = 30          # 启动后跳过的帧数（等待自动曝光稳定）

# ============================================================
# A4 纸物理参数（单位：mm）
# ============================================================
A4_SHORT_SIDE_MM = 210.0         # A4 纸短边
A4_LONG_SIDE_MM = 297.0          # A4 纸长边
A4_BLACK_BORDER_MM = 20.0        # 黑色边框线宽

# ============================================================
# 焦距标定
# ============================================================
CALIBRATION_DISTANCE_MM = 1000.0 # 标定时 A4 纸到摄像头的已知距离（mm）
CALIBRATION_A4_SIDE_MM = A4_LONG_SIDE_MM  # 用于标定计算的 A4 纸边（长边更稳定）

# ============================================================
# A4 轮廓检测 —— 自适应阈值法（Shape.py / Overlap.py）
# ============================================================
ADAPTIVE_THRESH_BLOCK = 61       # 自适应阈值块大小
ADAPTIVE_THRESH_C = 25           # 自适应阈值常数
A4_MORPH_KERNEL = (3, 3)         # 形态学操作核大小
A4_MIN_CONTOUR_AREA = 1000       # 最小轮廓面积（过滤噪声）
A4_POLY_EPSILON_SCALE = 0.03     # 多边形逼近精度系数（× 周长）
A4_AREA_RATIO_MIN = 0.05         # 轮廓面积/图像面积 最小比例
A4_AREA_RATIO_MAX = 0.95         # 轮廓面积/图像面积 最大比例

# ============================================================
# A4 轮廓检测 —— HSV 黑色掩码法（Spin.py / 旋转场景）
# ============================================================
HSV_BLACK_LOWER = (0, 0, 0)      # 黑色 HSV 下界
HSV_BLACK_UPPER = (180, 255, 60) # 黑色 HSV 上界
SPIN_DILATE_ITER = 2             # 膨胀迭代次数（旋转场景需要更多）
SPIN_ERODE_ITER = 1              # 腐蚀迭代次数
SPIN_KERNEL = (7, 7)             # 形态学操作核（旋转场景更大）
SPIN_POLY_EPSILON_SCALE = 0.15   # 旋转场景多边形逼近容差（更大，适应梯形畸变）
SPIN_CONTOUR_STABILITY = 0.6     # 轮廓稳定性阈值（帧间重叠比例）

# ============================================================
# 形状检测参数
# ============================================================
SHAPE_MIN_AREA = 50              # 最小轮廓面积（过滤噪点）
SHAPE_MAX_AREA_RATIO = 0.8       # A4 区域内轮廓面积占比上限

# 正方形
SQUARE_ANGLE_MIN = 85            # 正方形角度下限（度）
SQUARE_ANGLE_MAX = 95            # 正方形角度上限（度）
SQUARE_ASPECT_MAX = 0.15         # 正方形边长比上限

# 等边三角形
TRIANGLE_ANGLE_MIN = 55          # 等边三角形角度下限（度）
TRIANGLE_ANGLE_MAX = 65          # 等边三角形角度上限（度）
TRIANGLE_ASPECT_MAX = 0.15       # 等边三角形边长比上限

# 圆形
CIRCLE_MIN_CIRCULARITY = 0.75    # 最小圆度
CIRCLE_MIN_CORNERS = 6           # 最小角点数（近似圆的多边形至少6个顶点）
CIRCLE_AREA_MIN = 30             # 圆形面积下限
CIRCLE_AREA_MAX = 6000           # 圆形面积上限

# ============================================================
# 重叠检测参数
# ============================================================
RED_ANGLE_MIN = 80               # 红点角度下限（凸角，接近90度）
RED_ANGLE_MAX = 105              # 红点角度上限
OVERLAP_AREA_RATIO_MIN = 0.05    # 有用轮廓与最大轮廓面积比下限
OVERLAP_AREA_RATIO_MAX = 0.9     # 有用轮廓与最大轮廓面积比上限
RED_EDGE_MIN_LENGTH = 10         # 红点最小邻边长度

# ============================================================
# 距离滤波
# ============================================================
DISTANCE_FILTER_SIZE = 10        # 均值滤波窗口大小

# ============================================================
# 经验补偿系数（每台设备需独立标定调整）
# ============================================================
# 说明：这些系数来自原作者的经验调参，用于补偿低像素远距离误差。
#       在你的 MaixCam 2 上可能需要重新标定或设为 1.0。
COMPENSATION_LONG_RANGE = 1.0144 # Shape.py — 距离 ≥ 1760mm 时乘此系数
COMPENSATION_LONG_RANGE_THRESH = 176.0  # 触发距离阈值（cm）

COMPENSATION_FINE_MAZY = 0.98    # Fine_Mazy_Shape — 距离 ≥ 1600mm 时乘此系数
COMPENSATION_FINE_MAZY_THRESH = 160.0  # 触发距离阈值（mm）

COMPENSATION_OVERLAP = 1.1213    # Overlap — 重叠检测边长补偿

COMPENSATION_ROTATION = 1.0643   # Spin — 旋转检测边长补偿

# ============================================================
# UART 通信
# ============================================================
UART_DEVICE = "/dev/ttyS1"       # MaixCam 2 上 UART 设备路径
UART_BAUDRATE = 115200
UART_RX_PIN = "A31"              # MaixCam 2 UART1: A30=TX, A31=RX
UART_TX_PIN = "A30"              # MaixCam 2 UART1: A30=TX, A31=RX

# 数据包定义
PACKET_HEADER = (0xAA, 0xBB)
PACKET_TAIL_BASIC = (0xCC, 0xDD)     # 基础测量包尾
PACKET_TAIL_ADVANCED = (0xEE, 0xFF)  # 发挥测量包尾

# 触发指令定义（STM32 → MaixCam）
CMD_BASE_TRIGGER = b'\x01'       # 基础测量触发
CMD_ADVANCED_1 = b'\x02'         # 发挥1：分离正方形
CMD_ADVANCED_2 = b'\x03'         # 发挥2：重叠正方形
CMD_ADVANCED_3 = b'\x04'         # 发挥3：数字编号正方形
CMD_ADVANCED_4 = b'\x05'         # 发挥4：旋转目标物

# 标定完成信号
CALIB_DONE_SIGNAL = b'\xAA\xBB\x00\x01\x00\x00\xCC\xDD'

# ============================================================
# 调试模式
# ============================================================
# debug: run debug.py without UART; uart: run the STM32 state machine
PROGRAM_MODE = "uart"

# a4 / basic / separated / overlap / rotation
DEBUG_TASK = "overlap"
DEBUG_VIEW = "result"             # result / binary
DEBUG_PRINT_INTERVAL = 10         # Print one result every N frames

# Internal compatibility options used by vision.py.
RUN_MODE = DEBUG_TASK
DEBUG_BINARY_VIEW = DEBUG_VIEW == "binary"
DEBUG_MODE = False                # 开启后打印详细诊断信息
